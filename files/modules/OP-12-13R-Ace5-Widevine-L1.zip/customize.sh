#!/system/bin/sh

ui_print "- Setting up Widevine L1 Keybox..."

KEYBOX_BIN="$MODPATH/system/vendor/bin/KmInstallKeybox"
ATTEST_FILE="$MODPATH/attestation"

chmod +x "$KEYBOX_BIN"
ui_print "- Reprogramming TEE..."
ui_print ""
LD_LIBRARY_PATH=/vendor/lib64:/vendor/lib64/hw "$KEYBOX_BIN" "$ATTEST_FILE" attestation true
ui_print ""
ui_print "It might show failed -2000, but dont worry its normal"
ui_print ""
ui_print "- TEE reprogramming complete."
