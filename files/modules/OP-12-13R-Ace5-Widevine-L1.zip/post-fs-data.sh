#!/system/bin/sh

MODDIR=${0%/*}

chcon u:object_r:vendor_file:s0 "$MODDIR/system/odm/lib64/liboemcrypto.so"
chcon u:object_r:vendor_file:s0 "$MODDIR/system/vendor/bin/KmInstallKeybox"

true
