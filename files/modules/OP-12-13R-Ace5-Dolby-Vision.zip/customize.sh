#!/system/bin/sh
MODDIR=${0%/*}

MEDIA_CODECS_FILES="
    etc/media_codecs_pineapple.xml
    etc/media_codecs_pineapple_vendor.xml
    etc/media_codecs_cliffs_v0.xml
"

for F in $MEDIA_CODECS_FILES; do
    SRC="/vendor/${F}"

    DST="$MODPATH/system/vendor/${F}"

    [ -f "$SRC" ] || continue

    mkdir -p "$(dirname "$DST")"

    cp "$SRC" "$DST"

    grep -i "media_codecs_dolby_vision.xml" "$DST" &> /dev/null && sed -i '/<MediaCodecs>/a\    <Include href="media_codecs_dolby_vision.xml" />' "$DST"
done

ui_print "Handled media codecs for pineapple (MODIFY THE SCRIPT IF YOUR TARGET XMLS in vendor are different)."
