#!/system/bin/sh

MODDIR=${0%/*}

chcon u:object_r:vendor_file:s0 "$MODDIR/system/odm/lib64/libdolbyclstc.so"
chcon u:object_r:vendor_file:s0 "$MODDIR/system/odm/lib64/libdolbydecoderprocessor.so"
chcon u:object_r:vendor_file:s0 "$MODDIR/system/odm/lib64/libdolbyeglcore.so"
chcon u:object_r:vendor_file:s0 "$MODDIR/system/odm/lib64/libdolbyencoderprocessor.so"
chcon u:object_r:vendor_file:s0 "$MODDIR/system/odm/lib64/libdolbyottcameracontrol.so"
chcon u:object_r:vendor_file:s0 "$MODDIR/system/odm/lib64/libqcodec2_dolbydecoderfilter.so"
chcon u:object_r:vendor_file:s0 "$MODDIR/system/odm/lib64/libqcodec2_dolbyencoderfilter.so"

chcon u:object_r:vendor_configs_file:s0 $MODDIR/system/vendor/etc/*.xml
chcon u:object_r:vendor_configs_file:s0 $MODDIR/system/vendor/etc/dolby_vision.cfg
chcon u:object_r:vendor_file:s0 $MODDIR/system/vendor/persist/display/dolby_vision.cfg
chcon u:object_r:vendor_configs_file:s0 $MODDIR/system/odm/etc/dolby/dolby_vision.cfg
chcon u:object_r:vendor_configs_file:s0 $MODDIR/system/odm/etc/dolby/display/dolby_vision.cfg

true
